// ignore: unused_import
import 'package:intl/intl.dart' as intl;
import 'app_localizations.dart';

// ignore_for_file: type=lint

/// The translations for French (`fr`).
class AppLocalizationsFr extends AppLocalizations {
  AppLocalizationsFr([String locale = 'fr']) : super(locale);

  @override
  String get appTitle => 'Build4All';

  @override
  String get signInGeneralTitle => 'Connectez-vous à votre compte';

  @override
  String get errEmailInvalid => 'Invalid email format';

  @override
  String get errEmailRequired => 'Email is required';

  @override
  String get lblEmail => 'Email';

  @override
  String get hintEmail => 'email';

  @override
  String get signInGeneralSubtitle => 'Saisissez vos informations pour continuer';

  @override
  String get termsNotice => 'En continuant, vous acceptez nos Conditions et notre Politique de confidentialité';

  @override
  String get lblIdentifier => 'E-mail / Téléphone / Nom d’utilisateur';

  @override
  String get hintIdentifier => 'you@example.com ou +961xxxxxxxx ou nom d’utilisateur';

  @override
  String get lblPassword => 'Mot de passe';

  @override
  String get hintPassword => '•••••••••••';

  @override
  String get rememberMe => 'Se souvenir de moi';

  @override
  String get forgotPassword => 'Mot de passe oublié ?';

  @override
  String get btnSignIn => 'Se connecter';

  @override
  String get noAccount => 'Vous n’avez pas de compte ?';

  @override
  String get signUp => 'S’inscrire';

  @override
  String get errIdentifierRequired => 'L’identifiant est requis';

  @override
  String get errPasswordRequired => 'Le mot de passe est requis';

  @override
  String get errPasswordMin => '6 caractères minimum';

  @override
  String get showPasswordLabel => 'Afficher le mot de passe';

  @override
  String get hidePasswordLabel => 'Masquer le mot de passe';
}
