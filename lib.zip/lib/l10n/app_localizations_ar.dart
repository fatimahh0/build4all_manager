// ignore: unused_import
import 'package:intl/intl.dart' as intl;
import 'app_localizations.dart';

// ignore_for_file: type=lint

/// The translations for Arabic (`ar`).
class AppLocalizationsAr extends AppLocalizations {
  AppLocalizationsAr([String locale = 'ar']) : super(locale);

  @override
  String get appTitle => 'Build4All';

  @override
  String get signInGeneralTitle => 'سجّل الدخول إلى حسابك';

  @override
  String get errEmailInvalid => 'Invalid email format';

  @override
  String get errEmailRequired => 'Email is required';

  @override
  String get lblEmail => 'Email';

  @override
  String get hintEmail => 'email';

  @override
  String get signInGeneralSubtitle => 'أدخل بياناتك للمتابعة';

  @override
  String get termsNotice => 'بمتابعتك أنت توافق على الشروط وسياسة الخصوصية';

  @override
  String get lblIdentifier => 'البريد / الهاتف / اسم المستخدم';

  @override
  String get hintIdentifier => 'you@example.com أو ‎+961xxxxxxxx‎ أو اسم المستخدم';

  @override
  String get lblPassword => 'كلمة المرور';

  @override
  String get hintPassword => '•••••••••••';

  @override
  String get rememberMe => 'تذكّرني';

  @override
  String get forgotPassword => 'نسيت كلمة المرور؟';

  @override
  String get btnSignIn => 'تسجيل الدخول';

  @override
  String get noAccount => 'ليس لديك حساب؟';

  @override
  String get signUp => 'إنشاء حساب';

  @override
  String get errIdentifierRequired => 'الرجاء إدخال المُعرّف';

  @override
  String get errPasswordRequired => 'الرجاء إدخال كلمة المرور';

  @override
  String get errPasswordMin => 'الحد الأدنى 6 أحرف';

  @override
  String get showPasswordLabel => 'إظهار كلمة المرور';

  @override
  String get hidePasswordLabel => 'إخفاء كلمة المرور';
}
