// ignore: unused_import
import 'package:intl/intl.dart' as intl;
import 'app_localizations.dart';

// ignore_for_file: type=lint

/// The translations for English (`en`).
class AppLocalizationsEn extends AppLocalizations {
  AppLocalizationsEn([String locale = 'en']) : super(locale);

  @override
  String get appTitle => 'Build4All';

  @override
  String get signInGeneralTitle => 'Sign in to your account';

  @override
  String get errEmailInvalid => 'Invalid email format';

  @override
  String get errEmailRequired => 'Email is required';

  @override
  String get lblEmail => 'Email';

  @override
  String get hintEmail => 'email';

  @override
  String get signInGeneralSubtitle => 'Enter your details to continue';

  @override
  String get termsNotice => 'By continuing you agree to our Terms & Privacy Policy';

  @override
  String get lblIdentifier => 'Email / Phone / Username';

  @override
  String get hintIdentifier => 'you@example.com or +961xxxxxxxx or username';

  @override
  String get lblPassword => 'Password';

  @override
  String get hintPassword => '•••••••••••';

  @override
  String get rememberMe => 'Remember me';

  @override
  String get forgotPassword => 'Forgot password?';

  @override
  String get btnSignIn => 'Sign In';

  @override
  String get noAccount => 'Don\'t have an account?';

  @override
  String get signUp => 'Sign Up';

  @override
  String get errIdentifierRequired => 'Identifier is required';

  @override
  String get errPasswordRequired => 'Password is required';

  @override
  String get errPasswordMin => 'Minimum 6 characters';

  @override
  String get showPasswordLabel => 'Show password';

  @override
  String get hidePasswordLabel => 'Hide password';
}
